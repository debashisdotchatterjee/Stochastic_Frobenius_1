STOCHASTIC FROBENIUS: REPRODUCIBLE EXPERIMENTAL PACKAGE

Analysis date (UTC): 2026-10-23T04:19:37.610206+00:00
Run profile: full
Master seed: 20261023

MODEL
- Four fixed, minimal generators: 5,6,7,8.
- IID packet sizes with probabilities .4,.3,.2,.1.
- Exact hitting event: at least one partial sum equals target n.
- True renewal limit: 1/6.
- True deterministic Frobenius number: 9.
- Exactly verified F_eta values: eta (.10,.12,.14,.15,.16) => (9,15,21,27,33).

DESIGN AND CLAIM STRENGTH
A. Tables 01-04 use exact Fraction rational arithmetic and independent
   recurrence / combinatorial enumeration / Markov matrix verification.
   Global matrix-minorization bounds certify that NO LARGER n violates each
   specified threshold. No finite-window extrapolation is used.
B. Figures 01-04 are deterministic model illustrations (not observations).
C. Figure 05 and Table 06 come from independent simulated renewal paths;
   Wilson limits describe Bernoulli Monte Carlo sampling, not uncertainty in p.
D. Figures 06-07 use floating-point recurrence with exact rational universal
   global tail bounds for the stated parameter families. Near-boundary
   classifications are re-evaluated using Fraction arithmetic.
E. Figures 08-10 are independent multinomial simulated training datasets.
   The delta-method normal approximation is asymptotic; threshold sampling
   frequencies do not constitute a guaranteed confidence interval.
F. Table 11 and Figure 13 evaluate finite-sample confidence reporting.
   Table 11 gives a finite-sample confidence reporting interval with the
   manuscript's Hoeffding+coupling guarantee and a sharpened rational
   sub-stochastic matrix tail certificate. Coverage guarantee means
   P(report interval AND miss true F) <= beta; it does NOT guarantee
   P(cover | reported) >= 1-beta. When no interval is reported, the answer
   is INCONCLUSIVE. Numerical endpoint comparisons are outward-safe.
G. Figure 13 estimates the probability of issuing an interval and the
   JOINT false-report probability over simulated datasets. Empirical
   frequencies are not a substitute for mathematical error control.
H. Figure 12 bootstrap percentiles are APPROXIMATE. They do NOT have a
   guaranteed finite-sample coverage theorem for the discontinuous F_eta.

OUTPUTS
- figures/ : 13 manuscript-grade plots as PNG (320dpi), PDF and SVG.
- tables/ : numbered CSV datasets and journal-compatible LaTeX tables.
- verification/: exact rational tail certificate and automatic assertions.
- run_manifest.json: software, parameters, random seeds, file hashes.
- source/: exact execution source and (if available) supplementary manuscript.
- source ZIP: all above in a single archive outside this directory.

NOTE ON SCIENTIFIC INTERPRETATION
This is a synthetic illustration of a precisely specified probabilistic model,
not a measurement of actual McDonald's ordering patterns. Confidence reporting
in the preceding theorem is deliberately conservative. Any proposed journal
submission should include further generator families, theory-audit, sensitivity
analysis, and a careful literature-based novelty statement.
