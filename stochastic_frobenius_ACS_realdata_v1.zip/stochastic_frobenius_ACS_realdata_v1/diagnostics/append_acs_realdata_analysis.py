"""2024 ACS PUMS real-data extension for the stochastic Frobenius paper.
APPEND ONLY: standalone; does not modify any earlier numerical study outputs.
All reported empirical values are computed from real downloaded ACS household files.
US Census Bureau FTP: https://www2.census.gov/programs-surveys/acs/data/pums/2024/1-Year/
PUMS survey replicate variance: (4/80)*sum_b (estimate_b - estimate_full)^2.
"""
from __future__ import annotations
import os, io, sys, json, time, zipfile, hashlib, warnings, platform, textwrap, shutil
from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction

import numpy as np
import pandas as pd
import scipy
from scipy.stats import chi2, norm
import matplotlib
import matplotlib.pyplot as plt
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ======================== USER CONFIGURATION ==========================
ACS_YEAR = 2024                      # 2024 ACS 1-year PUMS, released 2025
STATES = {"CA": "California", "TX": "Texas", "NY": "New York"}
A = np.array([5, 6, 7, 8], dtype=int)
QUOTAS = (15, 21, 27, 33)            # prespecified; do not select post hoc
SECONDARY_TARGET = 21
FRONTIER_LEVELS = (0.10, 0.12)      # both below 1/8
CURVE_MAX_N = 120
FRONTIER_MAX_N = 2000
ALPHA = 0.05
CHUNK_ROWS = 40000
BASE_URL = "https://www2.census.gov/programs-surveys/acs/data/pums/2024/1-Year"
OUTDIR = Path("stochastic_frobenius_ACS_realdata_v1")
CACHE_DIR = Path("acs_pums_2024_download_cache")
AUTO_DOWNLOAD_ZIP = True
# Optional: map state abbreviations to already downloaded official housing ZIP files:
# LOCAL_STATE_ZIPS = {"CA": "/content/csv_hca.zip", "TX": "/content/csv_htx.zip", "NY": "/content/csv_hny.zip"}
LOCAL_STATE_ZIPS = {}
# ======================================================================

FIGDIR = OUTDIR / "figures"
TABDIR = OUTDIR / "tables"
METADIR = OUTDIR / "diagnostics"
for d in (FIGDIR, TABDIR, METADIR, CACHE_DIR):
    d.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
                     "legend.fontsize": 8, "figure.dpi": 125, "savefig.dpi": 320,
                     "pdf.fonttype": 42, "ps.fonttype": 42})


def save_plot(fig, basename):
    fig.tight_layout()
    for suffix in ('pdf', 'png', 'svg'):
        fig.savefig(FIGDIR / f'{basename}.{suffix}', bbox_inches='tight')
    plt.show()
    plt.close(fig)


def save_csv(df, basename, index=False):
    target = TABDIR / f'{basename}.csv'
    df.to_csv(target, index=index, float_format='%.12g')
    print(f'  wrote {target}')


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fp:
        for chunk in iter(lambda: fp.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def download_state_zip(abbr):
    if abbr in LOCAL_STATE_ZIPS:
        p = Path(LOCAL_STATE_ZIPS[abbr])
        if not p.exists():
            raise FileNotFoundError(f'Local specified ZIP absent for {abbr}: {p}')
        return p, 'local user-supplied copy of official PUMS housing ZIP'
    p = CACHE_DIR / f'csv_h{abbr.lower()}.zip'
    url = f'{BASE_URL}/csv_h{abbr.lower()}.zip'
    if p.exists() and zipfile.is_zipfile(p) and p.stat().st_size > 100_000:
        print(f'  Using cached official ZIP for {abbr}: {p}')
        return p, url
    session = requests.Session()
    retries = Retry(total=4, backoff_factor=1.5, status_forcelist=[429,500,502,503,504])
    session.mount('https://', HTTPAdapter(max_retries=retries))
    print(f'  Downloading official household ZIP for {abbr}: {url}')
    tmp = p.with_suffix('.part')
    try:
        with session.get(url, stream=True, timeout=(20,120), headers={'User-Agent':'Research reproduction, academic use'}) as resp:
            resp.raise_for_status()
            with open(tmp, 'wb') as fo:
                for block in resp.iter_content(chunk_size=1024*1024):
                    if block: fo.write(block)
        if not zipfile.is_zipfile(tmp):
            raise RuntimeError(f'{url} did not return a ZIP archive')
        tmp.replace(p)
    except Exception as exc:
        if tmp.exists(): tmp.unlink()
        raise RuntimeError(f'Unable to fetch {url}: {exc}. Download the same file from the '
                           'Census 2024 ACS PUMS FTP directory, upload to Colab, and set LOCAL_STATE_ZIPS.') from exc
    return p, url


def state_household_summary(abbr):
    """Read official housing data in chunks and aggregate four eligibility categories.
    No sampling, no person-level rows, no unweighted multinomial inference.
    """
    zip_path, source = download_state_zip(abbr)
    need = {'NP','WGTP'} | {f'WGTP{j}' for j in range(1,81)}
    totals = np.zeros((81,4), dtype=float)  # full + 80 SDR replicate weights
    n_rows = n_eligible = n_invalid_weight = n_bad_np = 0
    with zipfile.ZipFile(zip_path) as zf:
        members = [name for name in zf.namelist() if name.lower().endswith('.csv') and not name.startswith('__MACOSX')]
        if len(members) != 1:
            raise ValueError(f'{zip_path} expected one housing CSV, found: {members}')
        with zf.open(members[0]) as fh:
            reader = pd.read_csv(fh, usecols=lambda name: name.strip().upper() in need,
                                 chunksize=CHUNK_ROWS, low_memory=False)
            for chunk in reader:
                chunk.columns = chunk.columns.str.upper().str.strip()
                missing = need - set(chunk.columns)
                if missing:
                    raise ValueError(f'{abbr} missing required household columns: {sorted(missing)}')
                n_rows += len(chunk)
                np_ = pd.to_numeric(chunk['NP'], errors='coerce').to_numpy(dtype=float)
                w = chunk[['WGTP'] + [f'WGTP{j}' for j in range(1,81)]].apply(
                    pd.to_numeric, errors='coerce').to_numpy(dtype=float)
                valid_weights = (np.isfinite(w).all(axis=1) & (w[:,0] > 0) & (w >= 0).all(axis=1))
                eligible_np = np.isin(np_, A)
                n_bad_np += int((~np.isfinite(np_)).sum())
                n_invalid_weight += int((eligible_np & ~valid_weights).sum())
                ok = eligible_np & valid_weights
                n_eligible += int(ok.sum())
                for j, a in enumerate(A):
                    totals[:, j] += w[ok & (np_ == a)].sum(axis=0)
    denom = totals.sum(axis=1)
    if n_eligible < 100 or not np.all(np.isfinite(denom)) or not np.all(denom > 0):
        raise ValueError(f'{abbr} insufficient or invalid eligible households: {n_eligible}')
    probs = totals / denom[:,None]
    if not np.all(probs > 0) or not np.allclose(probs.sum(axis=1),1.0,atol=1e-12):
        raise ValueError(f'{abbr} has missing categories or invalid probabilities')
    print(f'  {abbr}: {n_rows:,} housing records, {n_eligible:,} eligible, '
          f'weighted p={np.round(probs[0],5)}')
    return probs, dict(state=abbr, state_name=STATES[abbr], source=source,
                       zip_name=zip_path.name, zip_sha256=file_sha256(zip_path),
                       rows_total=n_rows, eligible_records=n_eligible,
                       excluded_eligible_invalid_weights=n_invalid_weight,
                       nonnumeric_np_rows=n_bad_np,
                       estimated_eligible_households=denom[0],
                       min_replicate_eligible_weight=denom[1:].min()), totals


def renewal_batch(p, max_n=CURVE_MAX_N):
    """Vectorized exact recurrence (up to floating-point rounding)."""
    p = np.asarray(p, float)
    if p.shape[-1] != 4 or not np.allclose(p.sum(axis=-1), 1.0, atol=1e-10):
        raise ValueError('Every probability vector must have 4 entries summing to 1')
    shp = p.shape[:-1]
    arr = p.reshape(-1,4)
    u = np.zeros((arr.shape[0],max_n+1))
    u[:,0] = 1.0
    for n in range(1,max_n+1):
        for j, a in enumerate(A):
            if n >= a:
                u[:,n] += arr[:,j] * u[:,n-a]
    return u.reshape(*shp,max_n+1)


def frontier(p, eta, max_n=FRONTIER_MAX_N):
    """Finite safe-block certificate, not an arbitrary scan cutoff."""
    p = np.asarray(p,dtype=float)
    assert p.shape==(4,) and np.all(p>0) and np.isclose(p.sum(),1)
    if not (0 < eta < 1.0 / np.dot(A,p)):
        raise ValueError(f'Eta {eta} is outside the mathematically finite regime')
    u = np.zeros(max_n+1, dtype=float)
    u[0]=1.0
    consecutive=0; last_bad=None
    for n in range(1,max_n+1):
        for j,a in enumerate(A):
            if n>=a: u[n] += p[j]*u[n-a]
        if u[n]<eta:
            last_bad=n; consecutive=0
        else:
            consecutive += 1
        if consecutive >= int(A.max()):
            return int(last_bad) if last_bad is not None else 0, n-int(A.max())+1, n
    raise RuntimeError(f'Unable to certify finite frontier at eta={eta} by n={max_n}; '
                       'increase FRONTIER_MAX_N. No approximate value will be returned.')


def frontier_rational_from_integer_totals(category_totals, eta_string, max_n=FRONTIER_MAX_N):
    """Entirely exact threshold and safe-block proof for integer household weights.
    Intended only for the official ACS weights, which are published as integers.
    Returns None for non-integer synthetic/externally supplied weights.
    """
    v=np.asarray(category_totals,dtype=float)
    if (not np.all(np.isfinite(v)) or np.any(v<=0) or
        np.max(np.abs(v-np.rint(v)))>1e-8 or np.max(v)>2**53):
        return None
    counts=[int(round(x)) for x in v]
    den=sum(counts)
    P=[Fraction(c,den) for c in counts]
    eta=Fraction(str(eta_string))
    mean=sum(Fraction(int(a))*p for a,p in zip(A,P))
    if not (Fraction(0)<eta<1/mean):
        raise ValueError('Rational reliability level outside finite frontier regime')
    U=[Fraction(1)]
    consecutive=0; last_bad=None
    for n in range(1,max_n+1):
        x=sum((P[j]*U[n-int(a)] for j,a in enumerate(A) if n>=a),Fraction(0))
        U.append(x)
        if x<eta:
            last_bad=n;consecutive=0
        else:consecutive+=1
        if consecutive>=int(A.max()):
            return (int(last_bad) if last_bad is not None else 0,
                    n-int(A.max())+1,n)
    raise RuntimeError('Rational certification failed within the allowed iteration window')


def derivatives_at_quota(p, quotas):
    """Exact analytic derivatives w.r.t. p5,p6,p7 with p8 determined by simplex."""
    p = np.asarray(p,float)
    cap = int(max(quotas))
    u=np.zeros(cap+1); d=np.zeros((3,cap+1)); u[0]=1
    for n in range(1,cap+1):
        u[n] = sum(p[j]*u[n-a] for j,a in enumerate(A) if n>=a)
        for k in range(3):
            first = u[n-A[k]] if n>=A[k] else 0.
            last = u[n-A[-1]] if n>=A[-1] else 0.
            d[k,n] = first-last + sum(p[j]*d[k,n-a] for j,a in enumerate(A) if n>=a)
    grad = np.mean(d[:,list(quotas)],axis=1)
    return grad, d[:,SECONDARY_TARGET].copy()


def rep_cov(reps, base):
    reps = np.asarray(reps, float)
    base = np.asarray(base, float)
    diff = reps - base[None,:]
    return (4.0/80.0) * diff.T @ diff


def do_wald(values, replicated, label):
    """H0: values CA == TX == NY, df=2, matched SDR covariance."""
    C=np.array([[-1,1,0],[-1,0,1]],float)
    cov = rep_cov(replicated,values)
    S=C@cov@C.T
    evals = np.linalg.eigvalsh(S)
    if not np.all(np.isfinite(S)) or evals[0]<=0 or np.linalg.cond(S)>1e12:
        return dict(metric=label, statistic=np.nan, df=2, p_value=np.nan,
                    variance_condition=np.linalg.cond(S), warning='singular or ill-conditioned covariance'), cov
    diff=C@values
    w=float(diff@np.linalg.solve(S,diff))
    return dict(metric=label, statistic=w, df=2, p_value=chi2.sf(w,df=2),
                variance_condition=np.linalg.cond(S), warning=''), cov


def holm_adjust(values):
    p=np.asarray(values,float)
    valid=np.isfinite(p)
    ans=np.full(p.shape,np.nan)
    loc=np.where(valid)[0]; m=len(loc)
    order=loc[np.argsort(p[loc])]
    previous=0
    for rank,k in enumerate(order):
        previous=max(previous,min(1.0,(m-rank)*p[k]))
        ans[k]=previous
    return ans


def latex_table_state(base_p, se_p, stats, all_R, se_R, fvals):
    out=[r'\begin{table}[t]',r'\centering',
         r'\caption{ACS-calibrated household composition and exact-recruitment reliability. Probabilities and $R$ are survey-weighted; parenthesized values are SDR standard errors. Frontier estimates are descriptive.}',
         r'\label{tab:acs:primary}',r'\small',r'\begin{tabular}{lcccccc}',r'\toprule',
         r'State & $p_5$ & $p_6$ & $p_7$ & $p_8$ & $R$ & $(F_{.10},F_{.12})$\\',r'\midrule']
    for i,(st, name) in enumerate(STATES.items()):
        terms=[f'{base_p[i,j]:.3f} ({se_p[i,j]:.3f})' for j in range(4)]
        val=f'{all_R[i]:.4f} ({se_R[i]:.4f})'
        out.append(' & '.join([st]+terms+[val, f'$({fvals[i,0]},{fvals[i,1]})$']) + r'\\')
    out += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    (TABDIR/'table_ACS_main_manual.tex').write_text('\n'.join(out)+'\n')


def latex_table_wald(df):
    lines=[r'\begin{table}[t]',r'\centering',
           r'\caption{Prespecified design-based tests of equality across three states. Holm adjustment controls the two-test family under the stated design asymptotics.}',
           r'\label{tab:acs:wald}',r'\begin{tabular}{lrrr}',r'\toprule',
           r'Functional & $W$ ($df=2$) & $p$ & Holm-adjusted $p$\\',r'\midrule']
    for _,r in df.iterrows():
        nm=r'$R$' if r.metric=='quota_average_R' else r'$u_{21}$'
        lines.append(f'{nm} & {r.statistic:.3f} & {r.p_value:.4g} & {r.p_holm:.4g}'+r'\\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    (TABDIR/'table_ACS_tests_manual.tex').write_text('\n'.join(lines)+'\n')


def run():
    print('=== ACS 2024 PUMS: REAL DATA (not a simulation) ===')
    print('Conditional on sizes 5,6,7,8; states CA/TX/NY; 80 housing replicate weights.')
    infos=[]; prob_by_state=[]; count_by_state=[]
    for st in STATES:
        P,info,raw_weight_totals=state_household_summary(st)
        prob_by_state.append(P)
        infos.append(info)
        count_by_state.append(raw_weight_totals)
    P=np.stack(prob_by_state,axis=0)     # state x (full+80) x category
    base=P[:,0,:]                        # 3 x 4
    rp=np.transpose(P[:,1:,:],(1,0,2))   # 80 x 3 x 4
    assert np.allclose(base.sum(axis=1),1)
    assert (base>0).all()
    # Full observed + all survey replicates, same renewal calculations.
    U=renewal_batch(base)
    Ur=renewal_batch(rp)
    valsR=U[:,list(QUOTAS)].mean(axis=1)
    repsR=Ur[:,:,list(QUOTAS)].mean(axis=2)
    val21=U[:,SECONDARY_TARGET]
    rep21=Ur[:,:,SECONDARY_TARGET]
    tests=[]; covs={}
    for name, vals, reps in [('quota_average_R',valsR,repsR),('target_u21',val21,rep21)]:
        result,cov=do_wald(vals,reps,name)
        tests.append(result); covs[name]=cov
    tdf=pd.DataFrame(tests)
    tdf['p_holm']=holm_adjust(tdf['p_value'].to_numpy())
    if tdf.p_value.isna().any():
        print('WARNING: at least one omnibus test has unreliable covariance; see diagnostic table.')

    # Diagnostic covariance in 9 free simplex coordinates.
    theta=base[:,:3].reshape(-1)
    theta_reps=rp[:,:,:3].reshape(80,-1)
    Vtheta=rep_cov(theta_reps,theta)
    ep=np.sqrt(np.maximum(0,np.diag(rep_cov(rp.reshape(80,-1),base.reshape(-1))))).reshape(3,4)
    seR=np.sqrt(np.diag(covs['quota_average_R']))
    se21=np.sqrt(np.diag(covs['target_u21']))
    gradients=np.array([derivatives_at_quota(base[i],QUOTAS)[0] for i in range(3)])
    grads21=np.array([derivatives_at_quota(base[i],QUOTAS)[1] for i in range(3)])
    frontier_arr=np.array([[frontier(base[i], eta)[0] for eta in FRONTIER_LEVELS] for i in range(3)],int)
    cert=[[frontier(base[i],eta) for eta in FRONTIER_LEVELS] for i in range(3)]
    names=list(STATES.keys())
    exact_certificates=[]
    for i,st in enumerate(names):
        for t,eta in enumerate(FRONTIER_LEVELS):
            ex=frontier_rational_from_integer_totals(count_by_state[i][0],str(eta))
            matches=(ex is None) or (ex==cert[i][t])
            if not matches:
                raise AssertionError(f'{st}, eta={eta}: floating and exact rational certificates disagree')
            if ex is not None:
                frontier_arr[i,t]=ex[0]
                cert[i][t]=ex
            exact_certificates.append(dict(state=st,eta=eta,
                 exact_rational_weights=ex is not None,
                 verified=matches,
                 frontier=cert[i][t][0],safe_block_start=cert[i][t][1],
                 safe_block_end=cert[i][t][2]))
    save_csv(pd.DataFrame(exact_certificates),'Table12_exact_rational_certification')
    rep_frontier=np.array([[[frontier(rp[r,i],eta)[0] for eta in FRONTIER_LEVELS]
                            for i in range(3)] for r in range(80)],int)
    mu=base@A
    names=list(STATES.keys())

    # (1) Scientific tables and integrity diagnostics.
    sdf=pd.DataFrame(infos)
    for j,a in enumerate(A):
        sdf[f'p_{a}']=base[:,j]
        sdf[f'se_p_{a}_SDR']=ep[:,j]
    sdf['conditional_mu']=mu
    sdf['R']=valsR
    sdf['se_R_SDR']=seR
    sdf['u21']=val21
    sdf['se_u21_SDR']=se21
    for t,eta in enumerate(FRONTIER_LEVELS):
        sdf[f'F_eta_{eta}']=frontier_arr[:,t]
        sdf[f'certificate_safe_start_{eta}']=[cert[i][t][1] for i in range(3)]
        sdf[f'certificate_safe_end_{eta}']=[cert[i][t][2] for i in range(3)]
    save_csv(sdf, 'Table01_state_summaries')
    save_csv(tdf,'Table02_omnibus_Wald_tests')
    save_csv(pd.DataFrame(Vtheta,index=[f'{s}_p{j}' for s in names for j in [5,6,7]],
                          columns=[f'{s}_p{j}' for s in names for j in [5,6,7]]),
             'Table03_joint_free_coordinate_covariance',index=True)
    pd.DataFrame([dict(state=names[i],functional=fun,theta_coordinate=f'p{j}',derivative=der[i,jj])
                  for i in range(3)
                  for fun,der in [('R',gradients),('u21',grads21)]
                  for jj,j in enumerate([5,6,7])]).to_csv(
       TABDIR/'Table04_analytic_gradients.csv',index=False)

    curve=[]; curve_reps=[]
    for i,st in enumerate(names):
        for n in range(CURVE_MAX_N+1):
            sd=np.sqrt((4/80)*np.sum((Ur[:,i,n]-U[i,n])**2))
            curve.append(dict(state=st,n=n,u=U[i,n],se_SDR=sd,
                              lower_95_pointwise=max(0.,U[i,n]-norm.ppf(.975)*sd),
                              upper_95_pointwise=min(1.,U[i,n]+norm.ppf(.975)*sd)))
            for r in range(80):
                curve_reps.append((st,r+1,n,Ur[r,i,n]))
    cdf=pd.DataFrame(curve)
    save_csv(cdf,'Table05_renewal_curve_pointwise_uncertainty')
    save_csv(pd.DataFrame(curve_reps,columns=['state','replicate','n','u_replicate']),
             'Table06_all_replicate_renewal_curves')
    save_csv(pd.DataFrame([dict(state=names[i],replicate=r+1,eta=eta,
                                frontier=int(rep_frontier[r,i,t]))
                for r in range(80) for i in range(3)
                for t,eta in enumerate(FRONTIER_LEVELS)]),'Table07_replicate_frontier_diagnostics')
    save_csv(pd.DataFrame([dict(state=names[i],replicate=r+1,size=int(A[j]),probability=rp[r,i,j])
                for r in range(80) for i in range(3) for j in range(4)]),
             'Table08_replicate_household_size_probabilities')

    # Pairs: effect sizes and Bonferroni simultaneous 95% comparisons across
    # 3 pairs * 2 predeclared functionals (distinct from omnibus Holm).
    pairs=[(0,1),(0,2),(1,2)]
    bcrit=norm.ppf(1-ALPHA/(2*len(pairs)*2))
    lines=[]
    for metric, vals, reps in [('R', valsR,repsR),('u21',val21,rep21)]:
        for i,j in pairs:
            diff=float(vals[j]-vals[i]); diffs=reps[:,j]-reps[:,i]
            se=np.sqrt((4/80)*np.sum((diffs-diff)**2))
            lines.append(dict(metric=metric,comparison=f'{names[j]} - {names[i]}',
                              difference=diff,se_SDR=se,ci95_lower=diff-bcrit*se,
                              ci95_upper=diff+bcrit*se,
                              multiplicity='Bonferroni across 6 pairwise contrasts'))
    pair_df=pd.DataFrame(lines)
    save_csv(pair_df,'Table09_pairwise_effect_sizes_and_Bonferroni_CIs')

    # frontier sensitivity is descriptive: no frontier p-values or normal CIs.
    etagrid=np.round(np.linspace(.08,.12,41),5)
    fr_grid=np.array([[frontier(base[i],float(eta))[0] for eta in etagrid] for i in range(3)])
    save_csv(pd.DataFrame([dict(state=names[i],eta=eta,frontier=int(fr_grid[i,k]))
                           for i in range(3) for k,eta in enumerate(etagrid)]),
             'Table10_frontier_reliability_sensitivity')

    # Analytic gradient finite difference validation, NOT a theorem check by MC.
    derivative_checks=[]; h=1e-6
    for i,st in enumerate(names):
        for j in range(3):
            plus=base[i].copy(); minus=base[i].copy()
            plus[j]+=h;plus[3]-=h;minus[j]-=h;minus[3]+=h
            numeric=(renewal_batch(plus)[list(QUOTAS)].mean()-
                     renewal_batch(minus)[list(QUOTAS)].mean())/(2*h)
            derivative_checks.append(dict(state=st,coordinate=f'p{A[j]}',analytic=gradients[i,j],
                                          central_difference=numeric,absolute_difference=abs(numeric-gradients[i,j])))
    gdf=pd.DataFrame(derivative_checks)
    save_csv(gdf,'Table11_gradient_numerical_validation')
    assert float(gdf.absolute_difference.max()) < 1e-6, 'Gradient check failed; examine code'

    # Data quality and representative uncertainty plots.
    cats=np.arange(4); x=np.arange(3); fig,ax=plt.subplots(figsize=(8.3,3.8))
    bwidth=.18
    for j,a in enumerate(A):
        ax.bar(x+(j-1.5)*bwidth,base[:,j],bwidth,label=f'{a} persons',yerr=ep[:,j],capsize=2)
    ax.set_xticks(x,names);ax.set_ylabel('Conditional household share')
    ax.set_title('2024 ACS: weighted household-size composition with SDR standard errors')
    ax.legend(ncol=4,frameon=False,loc='upper center',bbox_to_anchor=(.5,-.14))
    save_plot(fig,'Fig21_ACS_weighted_household_composition')

    fig,axes=plt.subplots(1,3,figsize=(12.0,3.3),sharey=True)
    nn=np.arange(1,81)
    for i,ax in enumerate(axes):
        value=U[i,nn]
        sd=np.sqrt((4/80)*np.sum((Ur[:,i,nn]-value[None,:])**2,axis=0))
        ax.plot(nn,value,lw=1.5,label='Weighted plug-in')
        ax.fill_between(nn,np.maximum(0,value-1.96*sd),np.minimum(1,value+1.96*sd),
                        alpha=.20,label='Pointwise 95% normal approximation')
        for eta in FRONTIER_LEVELS:
            ax.axhline(eta,ls='--',lw=1,label=f'eta={eta}')
        ax.set_title(names[i]);ax.set_xlabel('Target participants, n');ax.set_ylim(0,.35)
        if i==0: ax.set_ylabel('Exact-hitting probability')
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=4,frameon=False,bbox_to_anchor=(.5,-.07))
    fig.subplots_adjust(bottom=.23)
    save_plot(fig,'Fig22_ACS_hitting_curves_pointwise_bands')

    fig,axes=plt.subplots(1,2,figsize=(10.2,3.4),sharey=True)
    for kk,j in enumerate([1,2]):
        ax=axes[kk]
        dn=U[j,:81]-U[0,:81]
        repdn=Ur[:,j,:81]-Ur[:,0,:81]
        sdn=np.sqrt((4/80)*np.sum((repdn-dn[None,:])**2,axis=0))
        ax.plot(np.arange(1,81),dn[1:],label='Observed difference')
        ax.fill_between(np.arange(1,81),dn[1:]-1.96*sdn[1:],dn[1:]+1.96*sdn[1:],alpha=.2)
        ax.axhline(0,ls='--',lw=1)
        ax.set_title(f'{names[j]} minus CA');ax.set_xlabel('Target n')
    axes[0].set_ylabel('Difference in exact-hitting probability')
    save_plot(fig,'Fig23_ACS_targetwise_regional_contrasts')

    fig,ax=plt.subplots(figsize=(7.4,3.4))
    for i in range(3):
        ax.errorbar(x[i],valsR[i],yerr=norm.ppf(.975)*seR[i],fmt='o',capsize=5)
        ax.text(x[i]+.06,valsR[i],f'{valsR[i]:.4f}',va='center',fontsize=8)
    ax.set_xticks(x,names);ax.set_ylabel('Mean exact-hitting reliability, R')
    ax.set_title(f'Prespecified quota average; omnibus Wald p={tdf.loc[0,"p_value"]:.3g}')
    save_plot(fig,'Fig24_ACS_quota_average_with_uncertainty')

    fig,ax=plt.subplots(figsize=(8.2,3.7))
    for i,st in enumerate(names):
        ax.step(etagrid,fr_grid[i],where='post',label=st)
    ax.set_xlabel('Reliability requirement, eta');ax.set_ylabel('Certified plug-in frontier')
    ax.set_title('Frontier is step-valued; these curves are descriptive, not confidence bands')
    ax.legend(frameon=False)
    save_plot(fig,'Fig25_ACS_frontier_sensitivity')

    fig,axes=plt.subplots(1,2,figsize=(10,3.5),sharey=True)
    for t,eta in enumerate(FRONTIER_LEVELS):
        ax=axes[t]
        locations=np.arange(3)
        vals=[rep_frontier[:,i,t].astype(float) for i in range(3)]
        ax.boxplot(vals,positions=locations,showfliers=True,patch_artist=False, widths=.45)
        ax.scatter(locations,frontier_arr[:,t],marker='D',s=42,label='Full-sample frontier',zorder=4)
        ax.set_xticks(locations,names);ax.set_title(f'eta={eta}; 80 replicate weights')
        ax.set_xlabel('State')
    axes[0].set_ylabel('Replicate-weight frontier (descriptive)')
    axes[0].legend(frameon=False,fontsize=8)
    save_plot(fig,'Fig26_ACS_replicate_frontier_variability')

    fig,axes=plt.subplots(1,2,figsize=(10.4,3.7))
    for kk,metric in enumerate(['R','u21']):
        ax=axes[kk]
        df=pair_df[pair_df.metric==metric]
        y=np.arange(len(df))
        val=df.difference.to_numpy(float)
        lower=df.ci95_lower.to_numpy(float)
        upper=df.ci95_upper.to_numpy(float)
        ax.errorbar(val,y,xerr=np.vstack([val-lower,upper-val]),fmt='o',capsize=4)
        ax.axvline(0,ls='--',lw=1)
        ax.set_yticks(y,df.comparison.tolist());ax.invert_yaxis()
        ax.set_xlabel('Estimated difference (Bonferroni-adjusted 95% CI)')
        ax.set_title('Quota average R' if kk==0 else 'Target probability u21')
    save_plot(fig,'Fig27_ACS_pairwise_survey_weighted_contrasts')

    latex_table_state(base,ep,sdf,valsR,seR,frontier_arr)
    latex_table_wald(tdf)
    (METADIR/'VARIABLES_AND_METHODS.txt').write_text(textwrap.dedent(f'''\
        2024 ACS 1-YEAR PUMS HOUSEHOLD-LEVEL RECORDS (CA/TX/NY).
        Variables NP (household persons), WGTP (housing unit weight), WGTP1-80.
        Analytic sample: NP in 5..8 and all finite nonnegative replicate weights,
        with WGTP strictly positive. Housing records only, no person records.
        Population estimand: conditional share among eligible households.
        Hypothetical recruitment: independent draws with replacement from that
        conditional composition. Not observed recruitment outcomes.
        SDR variance: 4/80 sum_b (replicate minus full weighted estimate)^2.
        Confidence intervals/bands are normal-approximation, design-CLT conditional.
        Figure 22-23 bands are POINTWISE, not simultaneous.
        Pairwise intervals are Bonferroni over six selected contrasts.
        Tests: omnibus chi-square(2) for preselected R and u21; Holm adjusted.
        Integer-valued frontier replicate distributions are DESCRIPTIVE.
        Frontier calculated by finite safe-block certificate, not a scan guess.
        Primary R targets: {QUOTAS}; secondary n={SECONDARY_TARGET}.
        Reliability thresholds: {FRONTIER_LEVELS}.
        No ACS PUMS API key is needed: FTP ZIP archive directly downloaded.
        No 'effect' or 'causality' established by geography comparison.
        ''').strip()+'\n')
    m={ 'dataset':'2024 ACS 1-year PUMS housing data', 'access_date_utc':datetime.now(timezone.utc).isoformat(),
        'dataset_source':BASE_URL, 'research_protocol':'hypothetical independent eligible-household recruitment',
        'states':STATES, 'a':A.tolist(), 'quotas':list(QUOTAS), 'secondary_n':SECONDARY_TARGET,
        'eta':list(FRONTIER_LEVELS), 'alpha':ALPHA, 'replicates':80, 'SDR_factor':4/80,
        'state_sources':infos, 'python':sys.version, 'numpy':np.__version__,
        'pandas':pd.__version__, 'scipy':scipy.__version__, 'matplotlib':matplotlib.__version__,
        'full_covariance_eigenvalues':np.linalg.eigvalsh(Vtheta).tolist(),
        'interpretive_warnings':['Survey design CLT and replicate consistency are assumptions, not an automatic theorem.',
                                  'Household composition is used to CALIBRATE a hypothetical independent recruitment process.',
                                  'No confidence guarantee is asserted for bootstrap/replicate frontier frequencies.',
                                  'Exact rational certificates are checked for official integer ACS weights.'] }
    (METADIR/'run_manifest.json').write_text(json.dumps(m,indent=2,default=float))
    print('\n=== PRIMARY REAL-DATA SUMMARY ===')
    print(sdf[['state','eligible_records','p_5','p_6','p_7','p_8','R','u21',
               'F_eta_0.1','F_eta_0.12']].to_string(index=False))
    print('\n=== DESIGN-BASED OMNIBUS TESTS ===')
    print(tdf.to_string(index=False))
    print('\n=== PAIRWISE BONFERRONI INTERVALS ===')
    print(pair_df.to_string(index=False))
    try:
        from IPython.display import display
        display(sdf.head(),tdf,pair_df)
    except Exception:
        pass
    outfile=OUTDIR.with_suffix('.zip')
    # Preserve input script and README as part of output for reproducibility.
    try:
        source_code=Path(__file__)
        if source_code.exists():
            shutil.copy2(source_code,METADIR/'append_acs_realdata_analysis.py')
    except NameError:
        pass
    with zipfile.ZipFile(outfile,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as f:
        for path in sorted(OUTDIR.rglob('*')):
            if path.is_file(): f.write(path,arcname=str(path.relative_to(OUTDIR.parent)))
    print(f'\nREADY: {outfile.resolve()} ({outfile.stat().st_size/1e6:.2f} MB)')
    if AUTO_DOWNLOAD_ZIP:
        try:
            from google.colab import files
            files.download(str(outfile))
        except ImportError:
            print('Not Colab: ZIP saved locally. Download through your runtime file browser.')

if __name__ == '__main__':
    run()
